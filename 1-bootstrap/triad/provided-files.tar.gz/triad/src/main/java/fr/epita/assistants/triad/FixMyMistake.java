package fr.epita.assistants.triad;

public class FixMyMistake {
    public static String myEasyFunction() {
        final String aMagicNumber = "42";
        // Place your cursor below on aMagicNumber and press Alt+Enter to fix the issue so that the method returns 43
        aMagicNumber = "43";
        return aMagicNumber;
    }
}
