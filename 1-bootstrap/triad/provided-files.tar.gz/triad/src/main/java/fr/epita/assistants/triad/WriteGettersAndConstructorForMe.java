package fr.epita.assistants.triad;

public class WriteGettersAndConstructorForMe {
    private final String name;
    private final String firstName;
    private final String lastName;

    private final String random;

    private final String anotherOne;

    private final String anotherOne2;

    private final String anotherOne3;

    private final String xyz;

    private final int x;

    private final double y;

    private final float z;

    private final Boolean b;

    private final boolean c;

    // FIXME: Add a constructor with all the parameters and all the getters
}
